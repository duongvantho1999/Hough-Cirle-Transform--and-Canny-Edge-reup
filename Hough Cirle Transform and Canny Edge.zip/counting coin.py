# import the necessary packages
import numpy as np
import argparse
import cv2
import time
width = 0
height = 0
eggCount = 0
exitCounter = 0
OffsetRefLines = 30 # Adjust ths value according to your usage
ReferenceFrame = None
distance_tresh_Y =200
distance_tresh_X=100
cap = cv2.VideoCapture('video-1620827617.mp4') # Set Capture Device, in case of a USB Webcam try 1, or give -1 to get a list of available devices
# The above step is to set the Resolution of the Video. The default is 640x480.
# This example works with a Resolution of 640x480.
def reScaleFrame(frame, percent=75):
    width = int(frame.shape[1] * percent // 100)
    height = int(frame.shape[0] * percent // 100)
    dim = (width, height)
    return cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)


ret, frame = cap.read()
frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)

frame40 = reScaleFrame(frame, percent=100)

height = np.size(frame40, 0)
width = np.size(frame40, 1)
Option = -20
coordYEntranceLine = (height // 2) + OffsetRefLines+Option
coordYMiddleLine = (height // 2)+Option
coordYExitLine = (height // 2) - OffsetRefLines+Option

def reScaleFrame(frame, percent=75):
    width = int(frame.shape[1] * percent // 100)
    height = int(frame.shape[0] * percent // 100)
    dim = (width, height)
    return cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)


def CheckInTheArea(coordYCircle, coordYEntranceLine, coordYExitLine):
    if ((coordYCircle <= coordYEntranceLine) and (coordYCircle >= coordYExitLine)):
        return 1
    else: 
        return 0


def CheckEntranceLineCrossing(coordYCircle, coordYEntranceLine):
    absDistance = abs(coordYCircle - coordYEntranceLine)

    if ((coordYCircle >= coordYEntranceLine) and (absDistance <=3)):
        return 1
    else:
        return 0


def getDistance(coordYEgg1, coordYEgg2):
    dist = abs(coordYEgg1 - coordYEgg2)

    return dist

while(True):
	# Capture frame-by-frame
	ret, frame = cap.read()
	frame40 = reScaleFrame(frame, percent=100)

	cv2.line(frame40, (0, coordYEntranceLine), (width, coordYEntranceLine), (255, 0, 0), 1)
	cv2.line(frame40, (0, coordYMiddleLine), (width, coordYMiddleLine), (0, 255, 0), 1)
	cv2.line(frame40, (0, coordYExitLine), (width, coordYExitLine), (255, 0, 0), 1)


	# load the image, clone it for output, and then convert it to grayscale
			
	output = frame40
	gray = cv2.cvtColor(frame40, cv2.COLOR_BGR2GRAY)
	
	# apply GuassianBlur to reduce noise. medianBlur is also added for smoothening, reducing noise.
	#gray = cv2.GaussianBlur(gray,(5,5),0);
	#ret,gray = cv2.threshold(frame40,127,255,cv2.THRESH_BINARY)
	# Adaptive Guassian Threshold is to detect sharp edges in the Image. For more information Google it.
	"""gray = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
            cv2.THRESH_BINARY,5,4)
	
	kernel = (2.6,2.7)
	gray = cv2.erode(gray,kernel,iterations = 1)
	# gray = erosion
	
	gray = cv2.dilate(gray,kernel,iterations = 1)"""
	# gray = dilation

	# get the size of the final image
	# img_size = gray.shape
	# print img_size
	
	# detect circles in the image
	circles=[]
	circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1,10, param1=50, param2=35, minRadius=10, maxRadius=50)
	# print circles
	egg_list=[]
	flag=False
	# ensure at least some circles were found
	if circles is not None:
		# convert the (x, y) coordinates and radius of the circles to integers
		circles = np.round(circles[0, :]).astype("int")
		
		# loop over the (x, y) coordinates and radius of the circles
		for i in range(len(circles)): #0 la hang
	        #contour la mot phan tu trong list chua cacs egg trong frame
			circle=circles[i]  #i la mot circle
			#contour la 1 tap hop cac diem tieu bieu tren duong bao cua 1 vungf dc cho la contour trong frame
			x=circle[0]
			y=circle[1]
			r=circle[2]

			egg_index = i

			egg_list.append([x, y, flag])
			#egg_list.append([x, y, flag])
			if (r <= int(50) and r >= int(37)):
				area = 3.14*r*r
	            # print("radius: ", radius)
	            # pprint.pprint(hierarchy)

	            #ellipse = cv2.fitEllipse(contour)
	            # (x, y, w, h) = cv2.boundingRect(contour)

	            #(center, axis, angle) = ellipse #axis co the la he so gian no
				coordXCircle, coordYCircle = int(x),int(y)
				
            #bo qua buoc checking dien tich khoi
				if area >= int(0) and area <= int(2000000):
	                #print('egg list: ' + str(egg_list) + ' index: ' + str(egg_index))
	                #neu nap chai lot vao khe giua 2 line thi ve duong bao va hien thi dien tich cua vung
					if CheckInTheArea(coordYCircle, coordYEntranceLine, coordYExitLine):
	                    #cv2.ellipse(frame40, (coordXCircle, coordYCircle), (ax1, ax2), orientation, 0, 360,
	                               # (255, 0, 0), 2)  # blue
						cv2.circle(frame40, (coordXCircle, coordYCircle), 1, (0, 255, 0), 15)  # green
						cv2.putText(frame40, str(int(area)), (coordXCircle, coordYCircle), cv2.FONT_HERSHEY_SIMPLEX,
						            0.5, 0, 1, cv2.LINE_AA)
					for k in range(len(egg_list)):
						egg_new_X = x
						egg_new_Y = y

						distY = getDistance(egg_new_Y,egg_list[k][1])
						distX=	getDistance(egg_new_X,egg_list[k][0])
						if (distY > distance_tresh_Y) and (distX > distance_tresh_X):  # distance_tresh = 200 or adjust
							egg_list.append([egg_new_X, egg_new_Y, flag])

					if CheckEntranceLineCrossing(egg_list[egg_index][1], coordYMiddleLine) and not egg_list[egg_index][2]:
						eggCount += 1
						egg_list[egg_index][2] = True

			cv2.circle(frame40, (x, y), r, (0, 255, 0), 2)
			#cv2.rectangle(output, (x - 5, y - 5), (x + 5, y + 5), (0, 128, 255), -1)
			#time.sleep(0.5)
			print ("Column Number: ")
			print (x)
			print ("Row Number: ")
			print (y)
			print ("Radius is: ")
			print (r)
			#cv2.imshow('frame40',output)
	# Display the resulting frame
	cv2.putText(frame40, "Entrance Eggs: {}".format(str(eggCount)), (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
	                        (250, 0, 1), 2)
	#cv2.imshow('gray',gray)
	cv2.imshow('frame',output)
	if cv2.waitKey(1) & 0xFF == ord('q'):
		break
# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()